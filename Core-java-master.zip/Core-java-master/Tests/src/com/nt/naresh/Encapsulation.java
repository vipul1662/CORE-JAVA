 
package com.nt.naresh;

public class Encapsulation {

}
