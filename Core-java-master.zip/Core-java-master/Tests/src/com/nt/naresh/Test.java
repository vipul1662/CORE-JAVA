package com.nt.naresh; 

public class Test extends Abstraction {//both are classes use extends 

	@Override
	public void m1(int a) {
		// TODO Auto-generated method stub

	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
