//person class
public class Person {//Encapsulated Class
	
	private String pName;
	
		public void setPName (String pName) {
			
			System.out.println("Encapsulation class::person");
		
				this.pName=pName;
			
		}
		public String  getPName() {
			return pName;
		}

}
