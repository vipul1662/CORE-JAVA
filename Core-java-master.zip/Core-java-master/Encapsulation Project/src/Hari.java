//user class
public class Hari {//User Class

	public static void main(String[] args) {
		Person p=new Person();
		p.setPName("Hari");
		System.out.println(p.getPName());
	}

}
