
public interface I1  {
	//implements  <------ Is used for developing inheritance between interface ,class..........
}
