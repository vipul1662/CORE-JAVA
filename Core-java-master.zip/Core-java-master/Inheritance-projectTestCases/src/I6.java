
public interface I6 extends I5{

}
