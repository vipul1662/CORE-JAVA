
public class B extends A{
	//extends  <---------Is used for developing inheritance  between two classes or two interfaces.....
	//The class or interface   that is placed BEFORE extends or implements is called SUB CLASS.
	//The class or interface   that is placed AFTER extends or  implements is called SUPER CLASS.
}
