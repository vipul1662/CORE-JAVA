
public class W {
 void m1() {
}
}
