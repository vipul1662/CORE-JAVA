
public abstract class U {
abstract void m1();
void m2() {
	
}
}
