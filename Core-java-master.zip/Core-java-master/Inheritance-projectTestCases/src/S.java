
public class S implements I5 {
public void m1() {
	
}
}
