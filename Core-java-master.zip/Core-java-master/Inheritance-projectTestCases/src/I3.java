
public interface I3 extends I1{
	//extends  <---------Is used for developing inheritance  between two classes or two interfaces.....
}
