
public interface I2 extends I1{
	//extends  <---------Is used for developing inheritance  between two classes or two interfaces.....
}
