//hello word 
public class HelloWord {

	public static void main(String[] args) {
		System.out.println("welcome to sankars world: ");
	}

}
