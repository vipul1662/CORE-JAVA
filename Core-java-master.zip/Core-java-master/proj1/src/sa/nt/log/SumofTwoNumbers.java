package sa.nt.log;

import java.util.Scanner;
public class SumofTwoNumbers {
	public static void main(String[] args) {
	int a=0;
	int b=0;
	int sum =0;
	Scanner sc=null;
	sc=new Scanner(System.in);
	System.out.print("Enetr a value: ");
	a=sc.nextInt();
	System.out.print("Enetr b value: ");
	b=sc.nextInt();
	System.out.println("Total: ");
	sum=a+b;
	System.out.println(sum);
	//close resources
	sc.close();
	
	
	
	
	}
}
