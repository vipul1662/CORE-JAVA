
public class Test1 {
	public static void main(String[] args) {
		byte b=11;//here bit=0 or 1 2bit equal to one byte
		byte b1=1;
		byte b2=127;
		System.out.println("b value is::"+b);
		System.out.println("b value is::"+b1);
		System.out.println("b value is::"+b2);
	}

}
