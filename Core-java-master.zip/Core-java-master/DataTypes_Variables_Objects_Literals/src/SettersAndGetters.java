
public class SettersAndGetters {

	public static void main(String[] args) {
		int age=90;
		System.out.println(age);
		

	}

}
