
public class Sample extends Abtract_Cases{
	@Override
	void m1() {
		
		
	}


	public static void main(String[] args) {
		
	}

	
}
