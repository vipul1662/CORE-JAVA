/*
 CUSTOM COLLECTION:
 
 1.size problem solved
 
 2.OPERATIONAL PROBLEM SOLVED
 
 */
public class Student {

}
