/**
 * this is java programming
 * java version is 1.9.0 version
 * jre adding to the eclipse
 * this is document command 
 */

/*
 * is used to multiple line command
 * is used in more than one line
 */








public class Commands {//this is class name
	int a=0;
	int getNumber() {//is used to single line command
		a=10;
		System.out.println("display Result: "+a);   
		return a;
		
	}

	public static void main(String[] args) {
		Commands cd=null;
		cd=new Commands(); 
		cd.getNumber();

	}

}
