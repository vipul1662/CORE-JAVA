//sub class extends example1
public class Sample2 extends Example1{
	void m3() {
		System.out.println("sub class of m3 method");
	}
	void m4() {
		System.out.println("sub class of m4 method");
	}

}
