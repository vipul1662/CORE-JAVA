
public class VarHidingVarShadow {

	public static void main(String[] args) {
		

	}

}
