package ru.re.va;

public class Student {
	int no;
	String name;
	String course;
	double fee;
	String email;
	long mobile;
	char gendel;
	boolean study;


}//class
